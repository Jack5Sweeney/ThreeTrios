package strategies;

import model.IModel;
import model.PlayerColor;

public class CornerStrategy implements IStrategy {

  @Override
  public Placement chooseMove(IModel model, PlayerColor player) {
    return null;
  }
}
