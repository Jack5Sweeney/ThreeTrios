package strategies;

import model.ModelImpl;
import model.PlayerImpl;

public interface IStrategy {

  Placement chooseMove(ModelImpl model, PlayerImpl player);

}
