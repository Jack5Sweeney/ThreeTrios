package provider.src.threetrios.view;


/**
 * Interface for the public methods of a hand-panel.
 */
public interface IHandPanel {

}
