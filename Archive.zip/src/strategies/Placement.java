package strategies;

public class Placement {
  public final int row, column;
  public Placement(int row, int column) {
    this.row = row;
    this.column = column;
  }
}
